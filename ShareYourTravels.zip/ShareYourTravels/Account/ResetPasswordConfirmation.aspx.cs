﻿using System.Web.UI;

namespace ShareYourTravels.Account
{
    public partial class ResetPasswordConfirmation : Page
    {
    }
}