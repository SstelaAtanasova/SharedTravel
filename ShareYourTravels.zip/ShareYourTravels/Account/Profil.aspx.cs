﻿using Microsoft.Ajax.Utilities;
using Microsoft.AspNet.Identity;
using Microsoft.AspNet.Identity.Owin;
using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data.SqlClient;
using System.Linq;
using System.Web;
using System.Web.Services.Description;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace ShareYourTravels.Account
{
    public partial class Profil : System.Web.UI.Page
    {
        string con = ConfigurationManager.ConnectionStrings["DefaultConnection"].ConnectionString;

        protected void Page_Load(object sender, EventArgs e)
        {
                      

            if (!IsPostBack)
            {

                LoadUserData();



            }


        }
        public void LoadUserData()
        {
            using (SqlConnection connection = new SqlConnection(con))
            {

                connection.Open();
                SqlCommand command = new SqlCommand();
                command.CommandText = @"SELECT FirstName, LastName, UserName, PhoneNumber FROM AspNetUsers WHERE Id = '" + HttpContext.Current.User.Identity.GetUserId() + "'";
                command.Connection = connection;

                SqlDataReader reader = command.ExecuteReader();

                while (reader.Read())
                {

                    this.fname.Text = Convert.ToString(reader["FirstName"]);
                    this.lname.Text = Convert.ToString(reader["LastName"]);
                    this.username.Text = Convert.ToString(reader["UserName"]);
                    this.phone.Text = Convert.ToString(reader["PhoneNumber"]);


                }

                connection.Close();

            }
        }      



   
protected void Button1_Click(object sender, EventArgs e)
        {
           
            using (SqlConnection connection = new SqlConnection(con))
            {
                connection.Open();
                SqlCommand command = new SqlCommand();
                command.CommandText = "UPDATE AspNetUsers SET FirstName = @FirstName, LastName = @LastName, PhoneNumber = @PhoneNumber WHERE AspNetUsers.Id= '" + HttpContext.Current.User.Identity.GetUserId() + "'";
                command.Connection = connection;

                command.Parameters.AddWithValue("@FirstName", fname.Text);
                command.Parameters.AddWithValue("@LastName", lname.Text);
                command.Parameters.AddWithValue("@PhoneNumber", phone.Text);

                command.ExecuteNonQuery();
                connection.Close();

                Response.Redirect("Manage.aspx");
            }
        }
    }
}
