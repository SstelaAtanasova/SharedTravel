﻿using Microsoft.AspNet.Identity;
using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data.SqlClient;
using System.IO;
using System.Linq;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace ShareYourTravels
{
    public partial class Car : System.Web.UI.Page
    {
        string con = ConfigurationManager.ConnectionStrings["DefaultConnection"].ConnectionString;

        protected void Page_Load(object sender, EventArgs e)
        {
            if (User.Identity.IsAuthenticated)
            {
                if (!IsPostBack)
                {

                  
                    using (SqlConnection connection = new SqlConnection(con))
                    {
                        SqlCommand command = new SqlCommand("SELECT * FROM BrandCar", connection);
                        connection.Open();
                        DropDownListBrand.DataSource = command.ExecuteReader();
                        DropDownListBrand.DataTextField = "Name";
                        DropDownListBrand.DataValueField = "BrandID";
                        DropDownListBrand.DataBind();

                        DropDownListBrand.Items.Insert(0, new ListItem("--Select--", "0"));
                    }

                }
            }
        }

        protected void DropDownListBrand_SelectedIndexChanged(object sender, EventArgs e)
        {
            DropDownListModel.Visible = true;

            using (SqlConnection connection = new SqlConnection(con))
            {
                SqlCommand command = new SqlCommand("SELECT * FROM ModelCar WHERE BrandID = @BrandID", connection);

                command.Parameters.AddWithValue("@BrandID", DropDownListBrand.SelectedValue);

                connection.Open();

                DropDownListModel.DataSource = command.ExecuteReader();
                DropDownListModel.DataTextField = "ModelName";
                DropDownListModel.DataValueField = "ModelID";
                DropDownListModel.DataBind();
                DropDownListModel.Items.Insert(0, new ListItem("--Select--", "0"));

                connection.Close();
            }

        }

        protected void ButtonSave_Click(object sender, EventArgs e)
        {
            if (!FileUploadPhotoCar.HasFile || TextBoxYear.Text == "" || DropDownListBrand.SelectedValue == null || DropDownListModel.SelectedValue == null)
            {
                LabelFields.Visible = true;
                LabelFields.Text = "Моля, попълнете задължителните полета!";
            }
            else
            {
                using (SqlConnection connection = new SqlConnection(con))
                {
                    connection.Open();
                                      

                    string path = Path.GetFileName(FileUploadPhotoCar.FileName);
                    path = path.Replace(" ", "");
                    String Filename = path;
                    FileUploadPhotoCar.SaveAs(Server.MapPath("~/Images/") + path);


                    SqlCommand command = new SqlCommand("INSERT INTO Car (Color, Year, Photo, ModelID, UserID) VALUES (@Color, @Year, @Photo, @ModelID, @UserID)",connection);

                    command.Parameters.AddWithValue("@Color", TextBoxColor.Text);
                    command.Parameters.AddWithValue("@Year", Convert.ToInt64(this.TextBoxYear.Text));
                    command.Parameters.AddWithValue("@Photo", path);
                    command.Parameters.AddWithValue("@ModelID", Convert.ToInt32(this.DropDownListModel.SelectedValue));
                    command.Parameters.AddWithValue("@UserID", HttpContext.Current.User.Identity.GetUserId());

                    command.ExecuteNonQuery();
                    connection.Close();
                   

                    this.Response.Redirect("AllCar.aspx");
                }
            }


        }

      
    }
}