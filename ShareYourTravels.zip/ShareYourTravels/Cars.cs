﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data.SqlClient;
using System.Linq;
using System.Web;

namespace ShareYourTravels
{
    public class Cars
    {
        private int carId;
        private string color;
        private int year;
        private string photo;
        private int modelId;

        public int CarID
        {
            get { return carId; }
            set { carId = value; }
        }
        public string Color
        {
            get { return color; }
            set { color = value; }
        }
        public int Year
        {
            get { return year; }
            set { year = value; }
        }
        public string Photo
        {
            get { return photo; }
            set { photo = value; }
        }
        public int ModelID
        {
            get { return modelId; }
            set { modelId = value; }
        }
    }

       
}