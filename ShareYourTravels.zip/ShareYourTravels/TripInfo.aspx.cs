﻿using Microsoft.AspNet.Identity;
using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data.SqlClient;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace ShareYourTravels
{
    public partial class TripInfo : System.Web.UI.Page
    {
        string con = ConfigurationManager.ConnectionStrings["DefaultConnection"].ConnectionString;

        protected void Page_Load(object sender, EventArgs e)
        {
            if (User.Identity.IsAuthenticated)
            {
                if (!IsPostBack)
                {                    
                    LoadTrip();
                    
                }
            }
        }
        public void LoadTrip()
        {
            using (SqlConnection connection = new SqlConnection(con))
            {
                connection.Open();
                SqlCommand command = new SqlCommand();
                command.CommandText = @"SELECT Trip.Date, Trip.FreeSeats, Trip.MoreInformation,
        Trip.Finished, 
	    Trip.PlaceBag,	
        Trip.FoodDrink,
		Trip.Smooking,		 
		Trip.Pet,
	    Trip.AirConditioning,
        Trip.Price,
		Car.Color, Car.Year, Car.Photo, ModelCar.ModelName, BrandCar.Name AS Expr1, UserTrip.UserID, Trip.TripID,
        (SELECT  PopulatedPlace.Name FROM PopulatedPlace JOIN TripPopulatedPlace ON TripPopulatedPlace.PlaceID = PopulatedPlace.PlaceID WHERE TripID=Trip.TripID AND Point like 'От') AS BeginCity,
	    (SELECT  PopulatedPlace.Name FROM PopulatedPlace JOIN TripPopulatedPlace ON TripPopulatedPlace.PlaceID = PopulatedPlace.PlaceID WHERE TripID=Trip.TripID AND Point like 'До') As EndCity
FROM            UserTrip INNER JOIN
                         Trip ON UserTrip.TripID = Trip.TripID
                         INNER JOIN
                         Car ON Trip.CarID = Car.CarID INNER JOIN
                         ModelCar ON Car.ModelID = ModelCar.ModelID INNER JOIN
                         BrandCar ON ModelCar.BrandID = BrandCar.BrandID
WHERE Trip.TripID= '" + Session["TripID"] + "'";

                command.Connection = connection;

                SqlDataReader reader = command.ExecuteReader();

                string finished = null;

                while (reader.Read())
                {
                    int tripId = Convert.ToInt32(reader["TripID"]);
                    this.LabelFrom.Text = Convert.ToString(reader["BeginCity"]);
                    this.LabelTo.Text = Convert.ToString(reader["EndCity"]);
                    this.LabelDateTime.Text = Convert.ToString(reader["Date"]);
                    this.LabelFreeSeats.Text = Convert.ToString(reader["FreeSeats"]);
                    this.LabelPrice.Text = Convert.ToInt32(reader["Price"]).ToString();                    
                    this.CheckBoxPlaceBag.Checked = Convert.ToBoolean(reader["PlaceBag"]);
                    this.CheckBoxSmooking.Checked = Convert.ToBoolean(reader["Smooking"]);
                    this.CheckBoxFood.Checked = Convert.ToBoolean(reader["FoodDrink"]);
                    this.CheckBoxPet.Checked = Convert.ToBoolean(reader["Pet"]);
                    this.CheckBoxAir.Checked = Convert.ToBoolean(reader["AirConditioning"]);
                    this.LabelInfo.Text = Convert.ToString(reader["MoreInformation"]);
                    this.LabelBrand.Text = Convert.ToString(reader["Expr1"]);
                    this.LabelModel.Text = Convert.ToString(reader["ModelName"]);
                    this.LabelColor.Text = Convert.ToString(reader["Color"]);
                    this.LabelYear.Text = Convert.ToString(reader["Year"]);
                    this.ImageCar.ImageUrl = "~/Images/" + reader["Photo"];
                    finished = Convert.ToString(reader["Finished"]);

                    if(finished == "False")
                    {
                        this.CheckBoxFinished.Checked = Convert.ToBoolean(reader["Finished"]);

                    }
                    else
                    {
                        this.CheckBoxFinished.Visible = false;
                        this.LabelFinished.Visible = true;
                        this.LabelFinished.Text = "Пътуването е приключено!";
                        this.ButtonSaveTrip.Visible = false;
                    }
                }

                connection.Close();


            }
        }


       
       
        protected void ButtonSaveTrip_Click(object sender, EventArgs e)
        {
            using (SqlConnection connection = new SqlConnection(con))
            {
                connection.Open();
                SqlCommand command = new SqlCommand();
                command.CommandText = "UPDATE Trip SET Finished = @Finished WHERE TripID= '" + Session["TripID"] + "'";

                command.Connection = connection;
                command.Parameters.AddWithValue("@Finished", this.CheckBoxFinished.Checked);

                command.ExecuteNonQuery();

                connection.Close();

                this.Response.Redirect("AllTrip.aspx");

            }
        }

        protected void ButtonDeleteTrip_Click(object sender, EventArgs e)
        {
            using (SqlConnection connection = new SqlConnection(con))
            {

                connection.Open();
                SqlCommand command = new SqlCommand();
                command.CommandText= @"SELECT  Trip.Date, Trip.FreeSeats, Trip.MoreInformation,
                       Trip.Finished, 
	                   Trip.PlaceBag,	
                       Trip.FoodDrink,
		               Trip.Smooking,		 
		               Trip.Pet,
	                   Trip.AirConditioning,
                        Trip.Price,
		Car.Color, Car.Year, Car.Photo, ModelCar.ModelName, BrandCar.Name AS Expr1, UserTrip.UserID, Trip.TripID,UserTrip.RoleID,
        (SELECT  PopulatedPlace.Name FROM PopulatedPlace JOIN TripPopulatedPlace ON TripPopulatedPlace.PlaceID = PopulatedPlace.PlaceID WHERE TripID=Trip.TripID AND Point like 'От') AS BeginCity,
	    (SELECT  PopulatedPlace.Name FROM PopulatedPlace JOIN TripPopulatedPlace ON TripPopulatedPlace.PlaceID = PopulatedPlace.PlaceID WHERE TripID=Trip.TripID AND Point like 'До') As EndCity
                  FROM            UserTrip INNER JOIN
                         Trip ON UserTrip.TripID = Trip.TripID
                         INNER JOIN
                         Car ON Trip.CarID = Car.CarID INNER JOIN
                         ModelCar ON Car.ModelID = ModelCar.ModelID INNER JOIN
                         BrandCar ON ModelCar.BrandID = BrandCar.BrandID
						 
                  WHERE UserTrip.RoleID IN (2,3,4,5) AND Trip.TripID= '" + Session["TripID"] + "'";

                command.Connection = connection;

                SqlDataReader reader = command.ExecuteReader();

                string roleID = null;
                if (reader.Read())
                {
                    roleID = Convert.ToString(reader["RoleID"]);


                }
                reader.Close();

                if (roleID == null)
                {
                    command.CommandText = "DELETE From UserTrip Where TripID= '" + Session["TripID"] + "'";
                    command.Connection = connection;
                    command.ExecuteNonQuery();
                    command.Parameters.Clear();

                    command.CommandText = "DELETE From TripPopulatedPlace Where TripID= '" + Session["TripID"] + "'";
                    command.Connection = connection;
                    command.ExecuteNonQuery();
                    command.Parameters.Clear();

                    command.CommandText = "DELETE From Trip Where TripID= '" + Session["TripID"] + "'";
                    command.Connection = connection;
                    command.ExecuteNonQuery();

                    connection.Close();
                    this.Response.Redirect("AllTrip.aspx");
                }
                else
                {
                    LabelNotDelete.Visible = true;
                    LabelNotDelete.Text = "Не можете да изтриете това пътуване, защото вече има потребители към него!";
                }

            }
        }



    }
}