﻿using Microsoft.AspNet.Identity;
using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace ShareYourTravels
{
    public partial class UserTripRole : System.Web.UI.Page
    {
        string con = ConfigurationManager.ConnectionStrings["DefaultConnection"].ConnectionString;

        protected void Page_Load(object sender, EventArgs e)
        {
            if (User.Identity.IsAuthenticated)
            {

                if (!IsPostBack)
                {
                    LoadRequestToMyTrip();
                    LoadRequestForMe();



                }

            }

        }

        public void LoadRequestToMyTrip()
        {
            using (SqlConnection connection = new SqlConnection(con))
            {
                DataTable result = new DataTable();
                result.Columns.Add("Id");
                result.Columns.Add("FirstName");
                result.Columns.Add("LastName");
                result.Columns.Add("RoleName");

                connection.Open();
                SqlCommand command = new SqlCommand();
                command.CommandText = @"SELECT AspNetUsers.FirstName, AspNetUsers.LastName, UserTripRole.RoleName, AspNetUsers.Id
                                        FROM AspNetUsers INNER JOIN UserTrip ON AspNetUsers.Id = UserTrip.UserID
                                                         INNER JOIN UserTripRole ON UserTrip.RoleID = UserTripRole.RoleID
                                                         INNER JOIN Trip ON Trip.TripID = UserTrip.TripID
                                       WHERE UserTrip.RoleID in (2,3,4,5) AND Trip.TripID IN (SELECT Trip.TripID 
                                                                                 FROM Trip INNER JOIN UserTrip ON Trip.TripID=UserTrip.TripID
											                                     INNER JOIN AspNetUsers ON AspNetUsers.Id = UserTrip.UserID
													                             INNER JOIN UserTripRole ON UserTripRole.RoleID = UserTrip.RoleID
										                                         WHERE Trip.TripID = UserTrip.TripID And UserTripRole.RoleID = 1
                                                                                 AND AspNetUsers.Id ='" + HttpContext.Current.User.Identity.GetUserId() + "')";

                command.Connection = connection;

                SqlDataReader reader = command.ExecuteReader();

                while (reader.Read())
                {
                    string id = Convert.ToString(reader["Id"]);
                    string firstName = Convert.ToString(reader["FirstName"]);
                    string lastName = Convert.ToString(reader["LastName"]);
                    string roleName = Convert.ToString(reader["RoleName"]);

                    DataRow row = result.NewRow();

                    row[0] = id;
                    row[1] = firstName;
                    row[2] = lastName;
                    row[3] = roleName;

                    result.Rows.Add(row);
                }
                GridViewMyTrip.DataSource = result;
                GridViewMyTrip.DataBind();
            }
        }

        public void LoadRequestForMe()
        {
            using (SqlConnection connection = new SqlConnection(con))
            {
                DataTable result = new DataTable();

                result.Columns.Add("Id");
                result.Columns.Add("BeginCity");
                result.Columns.Add("EndCity");
                result.Columns.Add("Date");
                result.Columns.Add("RoleName");

                connection.Open();
                SqlCommand command = new SqlCommand();

                command.CommandText = @"SELECT (SELECT  PopulatedPlace.Name FROM PopulatedPlace JOIN TripPopulatedPlace ON TripPopulatedPlace.PlaceID = PopulatedPlace.PlaceID WHERE TripID=Trip.TripID AND Point like 'От') AS BeginCity,
	                                  (SELECT  PopulatedPlace.Name FROM PopulatedPlace JOIN TripPopulatedPlace ON TripPopulatedPlace.PlaceID = PopulatedPlace.PlaceID WHERE TripID=Trip.TripID AND Point like 'До') As EndCity,
	                                  Trip.Date, UserTripRole.RoleName, AspNetUsers.Id, UserTrip.TripID
                                      FROM  AspNetUsers INNER JOIN UserTrip ON AspNetUsers.Id =UserTrip.UserID 
									                    INNER JOIN Trip ON Trip.TripID = UserTrip.TripID
                                                        INNER JOIN UserTripRole ON UserTrip.RoleID = UserTripRole.RoleID
                                      WHERE UserTripRole.RoleID in (2,3,4,5) AND AspNetUsers.Id ='" + HttpContext.Current.User.Identity.GetUserId() + "'";

                command.Connection = connection;

                SqlDataReader reader = command.ExecuteReader();

                while (reader.Read())
                {
                    //string id = Convert.ToString(reader["Id"]);
                    int tripId = Convert.ToInt32(reader["TripID"]);
                    string beginCity = Convert.ToString(reader["BeginCity"]);
                    string endCity = Convert.ToString(reader["EndCity"]);
                    string date = Convert.ToString(reader["Date"]);
                    string roleName = Convert.ToString(reader["RoleName"]);

                    DataRow row = result.NewRow();

                    //row[0] = id;
                    row[0] = tripId;
                    row[1] = beginCity;
                    row[2] = endCity;
                    row[3] = date;
                    row[4] = roleName;

                    result.Rows.Add(row);

                }
                GridViewFromMe.DataSource = result;
                GridViewFromMe.DataBind();
            }
        }

        protected void ButtonAccept_Click(object sender, EventArgs e)
        {
            using (SqlConnection connection = new SqlConnection(con))
            {
                Button btnAccept = (Button)sender;
                string id = btnAccept.CommandArgument.ToString();


                connection.Open();
                SqlCommand command = new SqlCommand();
                command.CommandText = "UPDATE UserTrip SET RoleID = @RoleID WHERE UserTrip.RoleID = 2 AND UserTrip.UserID='" + id + "'";
                command.Connection = connection;

                command.Parameters.AddWithValue("@RoleID", 3);
                command.ExecuteNonQuery();
                connection.Close();

                Response.Redirect(Request.RawUrl);



            }
        }

        protected void ButtonNotAccept_Click(object sender, EventArgs e)
        {
            using (SqlConnection connection = new SqlConnection(con))
            {
                Button btnNotAccept = (Button)sender;
                string id = btnNotAccept.CommandArgument.ToString();

                connection.Open();
                SqlCommand command = new SqlCommand();
                command.CommandText = "UPDATE UserTrip SET RoleID = @RoleID WHERE UserTrip.RoleID = 2 AND UserTrip.UserID='" + id + "'";
                command.Connection = connection;

                command.Parameters.AddWithValue("@RoleID", 4);
                command.ExecuteNonQuery();
                connection.Close();

                Response.Redirect(Request.RawUrl);



            }
        }

        protected void ButtonRefuseMe_Click(object sender, EventArgs e)
        {
            using (SqlConnection connection = new SqlConnection(con))
            {
                Button btnRefuseMe = (Button)sender;
                string tripId = btnRefuseMe.CommandArgument.ToString();

                connection.Open();
                SqlCommand command = new SqlCommand();
                command.CommandText = "UPDATE UserTrip SET RoleID = @RoleID WHERE UserTrip.UserID='" + HttpContext.Current.User.Identity.GetUserId() + "' AND UserTrip.TripID='" + tripId + "'";

                command.Connection = connection;

                command.Parameters.AddWithValue("@RoleID", 5);
                command.ExecuteNonQuery();
                connection.Close();

                Response.Redirect(Request.RawUrl);


            }
        }

        protected void GridViewMyTrip_RowDataBound(object sender, GridViewRowEventArgs e)
        {
            if (e.Row.RowType == DataControlRowType.DataRow)
            {
                Button btnAccept = e.Row.FindControl("ButtonAccept") as Button;
                Button btnNotAccept = e.Row.FindControl("ButtonNotAccept") as Button;

                if (e.Row.Cells[3].Text == "Приет" || e.Row.Cells[3].Text == "Отказан от шофьора" || e.Row.Cells[3].Text == "Отказан от кандидата")
                {
                    btnAccept.Visible = false;
                    btnNotAccept.Visible = false;
                }
                
            }       


            
        }

        protected void GridViewFromMe_RowDataBound(object sender, GridViewRowEventArgs e)
        {          

                    if (e.Row.RowType == DataControlRowType.DataRow)
                    {
                        Button btnRefuseMe = e.Row.FindControl("ButtonRefuseMe") as Button;

                        if (e.Row.Cells[4].Text == "Отказан от кандидата" || e.Row.Cells[4].Text == "Отказан от шофьора")
                        {
                            btnRefuseMe.Visible = false;


                        }
                    }
                
            
        }

        
    }
}
