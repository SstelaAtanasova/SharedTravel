﻿using Microsoft.Owin.Security.Provider;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Management;

namespace ShareYourTravels
{
    public class Trip
    {
        private int tripId;
        private string status;
        private DateTime date;
        private int freeSeats;
        private decimal price;
        private string moreInformation;
        private bool finished;
        private bool reported;
        private bool placeBag;
        private bool smooking;
        private bool foodDrink;
        private bool pet;
        private bool airConditioning;
        private string middleStop;
        private int carId;

        public int TripID
        {
            get { return tripId; }
            set { tripId = value; }
        }
        public string Status
        {
            get { return status; }
            set { status = value; }
        }

        public DateTime Date
        {
            get { return date; }
            set { date = value; }
        }

        public int FeeSeats
        {
            get { return freeSeats; }
            set { freeSeats = value; }
        }

        public decimal Price
        {
            get { return price; }
            set { price = value; }
        }

        public string MoreInformation
        {
            get { return moreInformation;  }
            set { moreInformation = value; }
        }

        public bool Finished
        {
            get { return finished; }
            set { finished = value; }
        }

        public bool Reported
        {
            get { return reported; }
            set { reported = value; }
        }
        public bool PlaceBag
        {
            get { return placeBag; }
            set { placeBag = value; }
        }
        public bool Smooking
        {
            get { return smooking; }
            set { smooking = value; }
        }
        public bool FoodDrink
        {
            get { return foodDrink; }
            set { foodDrink = value; }
        }
        public bool Pet
        {
            get { return pet; }
            set { pet = value; }
        }
        public bool AirConditioning
        {
            get { return airConditioning; }
            set { airConditioning = value; }
        }
        public string MiddleStop
        {
            get { return middleStop; }
            set { middleStop = value; }
        }

        public int CarId
        {
            get { return carId; }
            set { carId = value; }
        }
    }
}