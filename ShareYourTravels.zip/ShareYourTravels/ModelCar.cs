﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace ShareYourTravels
{
    public class ModelCar
    {
        private int modelID;
        private string modelName;
        private int brandID;

        public int ModelID
        {
            get { return modelID; }
            set { modelID = value; }
        }

        public string ModelName
        {
            get { return modelName; }
            set { modelName = value; }
        }
        public int BrandID
        {
            get { return brandID; }
            set { brandID = value; }
        }
        
    }
}