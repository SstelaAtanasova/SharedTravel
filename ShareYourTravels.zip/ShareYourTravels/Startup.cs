﻿using Microsoft.Owin;
using Owin;

[assembly: OwinStartupAttribute(typeof(ShareYourTravels.Startup))]
namespace ShareYourTravels
{
    public partial class Startup {
        public void Configuration(IAppBuilder app) {
            ConfigureAuth(app);
        }
    }
}
