﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace ShareYourTravels
{
    public partial class Search : System.Web.UI.Page
    {
        string con = ConfigurationManager.ConnectionStrings["DefaultConnection"].ConnectionString;

        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
            {
                LoadPopulatePlaceFrom();
                LoadPopulatePlaceTo();
            }

        }
        protected void Button1_Click(object sender, EventArgs e)
        {
            using (SqlConnection connection = new SqlConnection(con))
            {
                DataTable result = new DataTable();
                result.Columns.Add("TripID");
                result.Columns.Add("BeginCity");
                result.Columns.Add("EndCity");
                result.Columns.Add("Date");
                result.Columns.Add("FreeSeats");
                result.Columns.Add("Price");
               

                connection.Open();

                SqlCommand command = new SqlCommand();
                command.CommandText = string.Format(@"select 
       (SELECT  PopulatedPlace.Name FROM PopulatedPlace JOIN TripPopulatedPlace ON TripPopulatedPlace.PlaceID = PopulatedPlace.PlaceID WHERE TripID = Trip.TripID AND Point like 'От') AS BeginCity,
  	  (SELECT  PopulatedPlace.Name FROM PopulatedPlace JOIN TripPopulatedPlace ON TripPopulatedPlace.PlaceID = PopulatedPlace.PlaceID WHERE TripID = Trip.TripID AND Point like 'До') As EndCity,
	  Trip.TripID, Trip.Date, Trip.FreeSeats,Trip.Price

            from Trip
                     join TripPopulatedPlace as PlaceFrom on PlaceFrom.TripID = Trip.TripID 
                     join TripPopulatedPlace as PlaceTo on PlaceTo.TripID = Trip.TripID
                     join Car ON Trip.CarID = Car.CarID INNER JOIN
                      ModelCar ON Car.ModelID = ModelCar.ModelID INNER JOIN
                      BrandCar ON ModelCar.BrandID = BrandCar.BrandID
                where Trip.Finished = 0 and
            (PlaceFrom.Point like 'От'and PlaceFrom.PlaceID = {0})
                and 
		(PlaceTo.Point like 'До'and PlaceTo.PlaceID = {1})", DropDownListFromSearch.SelectedValue, DropDownListToSearch.SelectedValue);

                command.Connection = connection;

               

                SqlDataReader reader = command.ExecuteReader();

                while (reader.Read())
                {
                    int tripId = Convert.ToInt32(reader["TripID"]);
                    string beginCity = Convert.ToString(reader["BeginCity"]);
                    string endCity = Convert.ToString(reader["EndCity"]);
                    string date = Convert.ToString(reader["Date"]);
                    int freeSeats = Convert.ToInt32(reader["FreeSeats"]);
                    string price = Convert.ToInt32(reader["Price"]).ToString();

                    DataRow row = result.NewRow();

                    row[0] = tripId;
                    row[1] = beginCity;
                    row[2] = endCity;
                    row[3] = date;
                    row[4] = freeSeats;
                    row[5] = price;

                    result.Rows.Add(row);

                }
                GridViewSearch.DataSource = result;
                GridViewSearch.DataBind();
            }

        }
      

        protected void LoadPopulatePlaceFrom()
        {
            using (SqlConnection connection = new SqlConnection(con))
            {
                SqlCommand command = new SqlCommand("SELECT * FROM PopulatedPlace", connection);
                connection.Open();
                DropDownListFromSearch.DataSource = command.ExecuteReader();
                DropDownListFromSearch.DataTextField = "Name";
                DropDownListFromSearch.DataValueField = "PlaceID";
                DropDownListFromSearch.DataBind();

                DropDownListFromSearch.Items.Insert(0, new ListItem("--Избери--", "0"));

            }
        }

        protected void LoadPopulatePlaceTo()
        {
            using (SqlConnection connection = new SqlConnection(con))
            {
                SqlCommand command = new SqlCommand("SELECT * FROM PopulatedPlace", connection);
                connection.Open();
                DropDownListToSearch.DataSource = command.ExecuteReader();
                DropDownListToSearch.DataTextField = "Name";
                DropDownListToSearch.DataValueField = "PlaceID";
                DropDownListToSearch.DataBind();

                DropDownListToSearch.Items.Insert(0, new ListItem("--Избери--", "0"));

            }
        }

        protected void GridViewSearch_RowCommand(object sender, GridViewCommandEventArgs e)
        {
            if (e.CommandName == "Select")
            {
                Session["TripID"] = e.CommandArgument.ToString();

                this.Response.Redirect("TripDetailsSearch.aspx?tripId=" + Session["TripID"]);
            }
        }
    }
}