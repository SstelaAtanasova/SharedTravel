﻿using Microsoft.AspNet.Identity.EntityFramework;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace ShareYourTravels
{
    public class UserTrip
    {
        private string userId;
        private int tripId;
        private int roleId;

        public string UserID
        {
            get { return userId; }
            set { userId = value; }
        }
        public int TripID
        {
            get { return tripId; }
            set { tripId = value; }
        }
        public int RoleID
        {
            get { return roleId; }
            set { roleId = value; }
        }
    }
}