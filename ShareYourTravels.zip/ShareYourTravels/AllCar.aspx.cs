﻿using Microsoft.AspNet.Identity;
using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace ShareYourTravels
{
    
    public partial class AllCar : System.Web.UI.Page
    {
        string con = ConfigurationManager.ConnectionStrings["DefaultConnection"].ConnectionString;

        protected void Page_Load(object sender, EventArgs e)
        {
            if (User.Identity.IsAuthenticated)
            {
                if (!IsPostBack)
                {
                    LoadCar();

                }
            }
        }
        


        public void LoadCar()
        {
            using (SqlConnection connection = new SqlConnection(con))
            {
                DataTable result = new DataTable();
                result.Columns.Add("CarID");
                result.Columns.Add("Name");
                result.Columns.Add("ModelName");
                result.Columns.Add("Year");
                result.Columns.Add("Color");
                result.Columns.Add("Photo");

                connection.Open();
                SqlCommand command = new SqlCommand();
                command.CommandText = "SELECT * FROM Car JOIN ModelCar ON Car.ModelID = ModelCar.ModelID JOIN BrandCar ON ModelCar.BrandID = BrandCar.BrandID WHERE UserID = '" + HttpContext.Current.User.Identity.GetUserId() + "'";
                command.Connection = connection;

                SqlDataReader reader = command.ExecuteReader();
                
                while (reader.Read())
                {
                    int carId = Convert.ToInt32(reader["CarID"]);
                    string brandName = Convert.ToString(reader["Name"]);
                    string modelName = Convert.ToString(reader["ModelName"]);
                    int year = Convert.ToInt32(reader["Year"]);
                    string color = Convert.ToString(reader["Color"]);
                    string photo = Convert.ToString(reader["Photo"]);

                    DataRow row = result.NewRow();

                    row[0] = carId;
                    row[1] = brandName;
                    row[2] = modelName;
                    row[3] = year;
                    row[4] = color;
                    row[5] = photo;

                    result.Rows.Add(row);                    
                }
                GridViewContent.DataSource = result;
                GridViewContent.DataBind();


            }
        }

        protected void ButtonAddCar_Click(object sender, EventArgs e)
        {
            this.Response.Redirect("Car.aspx");
        }

        protected void GridViewContent_RowCommand(object sender, GridViewCommandEventArgs e)
        {
            if(e.CommandName == "Select")
            {
                Session["CarID"] = e.CommandArgument.ToString();
               
               this.Response.Redirect("CarInfo.aspx?carId=" + Session["CarID"]);
            }
        }

       
    }
}
