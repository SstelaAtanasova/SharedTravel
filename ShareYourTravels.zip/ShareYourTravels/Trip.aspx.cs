﻿using Microsoft.AspNet.Identity;
using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace ShareYourTravels
{
    
    public partial class Trip1 : System.Web.UI.Page
    {
        string con = ConfigurationManager.ConnectionStrings["DefaultConnection"].ConnectionString;

        protected void Page_Load(object sender, EventArgs e)
        {
            if (User.Identity.IsAuthenticated)
            {
                if (!IsPostBack)
                {
                    //при отваряне на страницата,календара и скрит
                    Calendar1.Visible = false;

                    LoadPopulatePlaceFrom();
                    LoadPopulatePlaceTo();
                    LoadCarUsers();


                }

            }

        }

        protected void ImageButton1_Click(object sender, ImageClickEventArgs e)
        {
            //при кликане на иконката да се отваря и затваря календара
            if (Calendar1.Visible)
            {
                Calendar1.Visible = false;
            }
            else
            {
                //календара се показва при кликане върху иконката
                Calendar1.Visible = true;
            }

        }

        protected void Calendar1_SelectionChanged(object sender, EventArgs e)
        {
            //попълване на тексбокса с дата при избор от календата и календара се затварв 
            TextBoxData.Text = Calendar1.SelectedDate.ToString();
            Calendar1.Visible = false;

        }

        protected void ButtonSaveTrip_Click(object sender, EventArgs e)
        {
            if (DropDownListFrom.SelectedValue == null || DropDownListTo.SelectedValue == null || TextBoxData.Text == "" || TextBoxFreeSeats.Text == "" || TextBoxPrice.Text == "" || DropDownListCar.SelectedValue == null)
            {
                LabelFields.Visible = true;
                LabelFields.Text = "Моля, попълнете задължителните полета!";
            }
            else
            {
                using (SqlConnection connection = new SqlConnection(con))
                {
                    connection.Open();
                    SqlCommand command = new SqlCommand();

                    command.CommandText = "INSERT INTO Trip (Date, FreeSeats, Price, MoreInformation, PlaceBag, Smooking, FoodDrink, Pet, AirConditioning, CarID, Finished) OUTPUT INSERTED.TripID VALUES (@Date, @FreeSeats, @Price, @MoreInfo, @PlaceBag, @Smooking, @FoodDrink, @Pet, @Air, @CarID, @Finished)";
                    int ID;
                    command.Parameters.AddWithValue("@Date", Convert.ToDateTime(this.TextBoxData.Text));
                    command.Parameters.AddWithValue("@FreeSeats", Convert.ToInt32(this.TextBoxFreeSeats.Text));
                    command.Parameters.AddWithValue("@Price", Convert.ToDecimal(this.TextBoxPrice.Text));
                    command.Parameters.AddWithValue("@MoreInfo", this.TextBoxMoreInfo.Text);
                    command.Parameters.AddWithValue("@PlaceBag", this.CheckBoxPlaceBag.Checked);
                    command.Parameters.AddWithValue("@Smooking", this.CheckBoxSmooking.Checked);
                    command.Parameters.AddWithValue("@FoodDrink", this.CheckBoxFood.Checked);
                    command.Parameters.AddWithValue("@Pet", this.CheckBoxPet.Checked);
                    command.Parameters.AddWithValue("@Air", this.CheckBoxAir.Checked);
                    command.Parameters.AddWithValue("@CarID", Convert.ToInt32(this.DropDownListCar.SelectedValue));
                    command.Parameters.AddWithValue("@Finished", false);
                    command.Connection = connection;
                    ID = (int)command.ExecuteScalar();
                    command.Parameters.Clear();


                    command.CommandText = "INSERT INTO UserTrip (UserID, TripID, RoleID) VALUES (@UserID, @TripID, @RoleID)";
                    command.Parameters.AddWithValue("@UserID", HttpContext.Current.User.Identity.GetUserId());
                    command.Parameters.AddWithValue("@TripID", ID);
                    command.Parameters.AddWithValue("@RoleID", 1);
                    command.Connection = connection;
                    command.ExecuteNonQuery();
                    command.Parameters.Clear();


                    command.CommandText = "INSERT INTO TripPopulatedPlace (PlaceID,TripID, Point) VALUES (@PlaceID, @TripID, 'От')";
                    command.Parameters.AddWithValue("@PlaceID", Convert.ToInt32(this.DropDownListFrom.SelectedValue));
                    command.Parameters.AddWithValue("TripID", ID);
                    command.Connection = connection;
                    command.ExecuteNonQuery();
                    command.Parameters.Clear();

                    command.CommandText = "INSERT INTO TripPopulatedPlace (PlaceID,TripID, Point) VALUES (@PlaceID, @TripID, 'До')";
                    command.Parameters.AddWithValue("@PlaceID", Convert.ToInt32(this.DropDownListTo.SelectedValue));
                    command.Parameters.AddWithValue("TripID", ID);
                    command.Connection = connection;
                    command.ExecuteNonQuery();
                    command.Parameters.Clear();

                    connection.Close();

                    this.Response.Redirect("AllTrip.aspx");


                }
            }
        } 

        protected void LoadPopulatePlaceFrom()
        {
            using (SqlConnection connection = new SqlConnection(con))
            {
                SqlCommand command = new SqlCommand("SELECT * FROM PopulatedPlace", connection);
                connection.Open();
                DropDownListFrom.DataSource = command.ExecuteReader();
                DropDownListFrom.DataTextField = "Name";
                DropDownListFrom.DataValueField = "PlaceID";
                DropDownListFrom.DataBind();

                DropDownListFrom.Items.Insert(0, new ListItem("--Избери--", "0"));

            }
        }

        protected void LoadPopulatePlaceTo()
        {
            using (SqlConnection connection = new SqlConnection(con))
            {
                SqlCommand command = new SqlCommand("SELECT * FROM PopulatedPlace", connection);
                connection.Open();
                DropDownListTo.DataSource = command.ExecuteReader();
                DropDownListTo.DataTextField = "Name";
                DropDownListTo.DataValueField = "PlaceID";
                DropDownListTo.DataBind();

                DropDownListTo.Items.Insert(0, new ListItem("--Избери--", "0"));

            }
        }

        protected void LoadCarUsers()
        {
            using (SqlConnection connection = new SqlConnection(con))
            {
                connection.Open();
                SqlCommand command = new SqlCommand();
                command.CommandText= @"SELECT CAST(BrandCar.Name AS VARCHAR(50)) + '  ' + CAST(ModelCar.ModelName AS VARCHAR(50)) + '   ' + CAST(Car.Year AS VARCHAR(50)) AS BrandModelYear, Car.CarID 
                                      FROM BrandCar INNER JOIN ModelCar ON BrandCar.BrandID = ModelCar.BrandID 
                                                   INNER JOIN Car ON ModelCar.ModelID = Car.ModelID
			                                       INNER JOIN AspNetUsers ON AspNetUsers.Id = Car.UserID
                                     WHERE AspNetUsers.Id ='" + HttpContext.Current.User.Identity.GetUserId() + "'";

                
                command.Connection = connection;
                DropDownListCar.DataSource = command.ExecuteReader();
                DropDownListCar.DataTextField = "BrandModelYear";
                DropDownListCar.DataValueField = "CarID";
                DropDownListCar.DataBind();

                DropDownListCar.Items.Insert(0, new ListItem("--Избери--", "0"));

            }

        }
    }
}