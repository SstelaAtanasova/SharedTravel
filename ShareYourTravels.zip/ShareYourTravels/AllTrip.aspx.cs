﻿using Microsoft.AspNet.Identity;
using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace ShareYourTravels
{
    public partial class AllTrip : System.Web.UI.Page
    {
		string con = ConfigurationManager.ConnectionStrings["DefaultConnection"].ConnectionString;

		protected void Page_Load(object sender, EventArgs e)
        {
			if (User.Identity.IsAuthenticated)
			{
				if (!IsPostBack)
				{

					LoadTrip();


				}
            }
        }
        protected void ButtonAddTrip_Click(object sender, EventArgs e)
        {
            this.Response.Redirect("Trip.aspx");
        }

        public void LoadTrip()
        {
			using (SqlConnection connection = new SqlConnection(con))
			{
				DataTable result = new DataTable();
				result.Columns.Add("TripID");
				result.Columns.Add("Role");
				result.Columns.Add("BeginCity");
				result.Columns.Add("EndCity");
				result.Columns.Add("Date");
				result.Columns.Add("FreeSeats");
				result.Columns.Add("Price");
				result.Columns.Add("StatusTrip");
				result.Columns.Add("Bags");
				result.Columns.Add("FoodsAndDrink");
				result.Columns.Add("Smook");
				result.Columns.Add("HomePet");
				result.Columns.Add("Air");
				result.Columns.Add("BrandName");
				result.Columns.Add("ModelName");

                connection.Open();
				SqlCommand command = new SqlCommand();

                command.CommandText = @"SELECT   CASE
         WHEN UserTrip.RoleID = 1 
		 THEN 'Шофьор' 
		 ELSE 'Пътник' 
		 END AS Role, Trip.Date, Trip.FreeSeats, Trip.Price, 
		 
		 CASE
		 WHEN Trip.MoreInformation like ''
		 THEN 'Няма'
		 ELSE Trip.MoreInformation
		 END as MoreInfo,
		 
		 CASE
         WHEN Trip.Finished = 0 
         THEN 'Ново'
         ELSE 'Приключило' 
         END AS StatusTrip,
		 CASE 
		 WHEN Trip.PlaceBag = 0
		 THEN 'Не'
		 ELSE 'Да'
		 END AS Bags,

		 CASE 
		 WHEN Trip.FoodDrink = 0
		 THEN 'Не'
		 ELSE 'Да'
		 END AS FoodsAndDrink,
		 
		 CASE 
		 WHEN Trip.Smooking = 0
		 THEN 'Не'
		 ELSE 'Да'
		 END As Smook,
		 
		 CASE
		 WHEN Trip.Pet = 0 
		 THEN 'Не'
		 ELSE 'Да'
		 END AS HomePet,
		 
		 CASE 
		 WHEN Trip.AirConditioning = 0
		 THEN 'Няма'
		 ELSE 'Има'
		 END AS Air, Car.Color, 
                         Car.Year, Car.Photo, ModelCar.ModelName, BrandCar.Name AS BrandName, AspNetUsers.Id, Trip.TripID
						 ,(SELECT  PopulatedPlace.Name FROM PopulatedPlace JOIN TripPopulatedPlace ON TripPopulatedPlace.PlaceID = PopulatedPlace.PlaceID WHERE TripID=Trip.TripID AND Point like 'От') AS BeginCity,
						 (SELECT  PopulatedPlace.Name FROM PopulatedPlace JOIN TripPopulatedPlace ON TripPopulatedPlace.PlaceID = PopulatedPlace.PlaceID WHERE TripID=Trip.TripID AND Point like 'До') As EndCity
FROM           AspNetUsers INNER JOIN UserTrip ON AspNetUsers.Id = UserTrip.UserID
                           INNER JOIN  Trip ON UserTrip.TripID = Trip.TripID
                                 INNER JOIN  Car ON Trip.CarID = Car.CarID 
								 INNER JOIN  ModelCar ON Car.ModelID = ModelCar.ModelID 
								 INNER JOIN  BrandCar ON ModelCar.BrandID = BrandCar.BrandID
WHERE UserTrip.RoleID = 1 AND AspNetUsers.Id= '" + HttpContext.Current.User.Identity.GetUserId() + "'";

				command.Connection = connection;

				SqlDataReader reader = command.ExecuteReader();

				while (reader.Read())
				{
					int tripId = Convert.ToInt32(reader["TripID"]);
					string role = Convert.ToString(reader["Role"]);
					string beginCity = Convert.ToString(reader["BeginCity"]);
					string endCity = Convert.ToString(reader["EndCity"]);
					string date = Convert.ToString(reader["Date"]);
					int freeSeats = Convert.ToInt32(reader["FreeSeats"]);
					string price = Convert.ToString(reader["Price"]);
					string finished = Convert.ToString(reader["StatusTrip"]);
					string bags = Convert.ToString(reader["Bags"]);
					string foodDring = Convert.ToString(reader["FoodsAndDrink"]);
					string smooking = Convert.ToString(reader["Smook"]);
					string pet = Convert.ToString(reader["HomePet"]);
					string air = Convert.ToString(reader["Air"]);
					string brandName = Convert.ToString(reader["BrandName"]);
					string modelName = Convert.ToString(reader["ModelName"]);

					DataRow row = result.NewRow();

					row[0] = tripId;
					row[1] = role;
					row[2] = beginCity;
					row[3] = endCity;
					row[4] = date;
					row[5] = freeSeats;
					row[6] = price;
					row[7] = finished;
					row[8] = bags;
					row[9] = foodDring;
					row[10] = smooking;
					row[11] = pet;
					row[12] = air;
					row[13] = brandName;
					row[14] = modelName;


					result.Rows.Add(row);

				}
				GridView1.DataSource = result;
				GridView1.DataBind();


				}
		}

        protected void GridView1_RowCommand(object sender, GridViewCommandEventArgs e)
        {
            if (e.CommandName == "Select")
            {
                Session["TripID"] = e.CommandArgument.ToString();                

                this.Response.Redirect("TripInfo.aspx?tripId=" + Session["TripID"]);
            }
        }
    }
}