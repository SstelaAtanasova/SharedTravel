﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace ShareYourTravels
{
    public class BrandCar
    {
        private int brandId;
        private string brandName;

        public int BrandID
        {
            get { return brandId; }
            set { brandId = value; }
        }
        public string BrandName
        {
            get { return brandName; }
            set { brandName = value; }
        }
    }
}