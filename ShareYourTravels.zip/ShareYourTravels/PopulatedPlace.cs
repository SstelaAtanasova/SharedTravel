﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace ShareYourTravels
{
    public class PopulatedPlace
    {
        private int placeId;
        private string placeName;

        public int PlaceID
        {
            get { return placeId; }
            set { placeId = value; }
        }
        public string PlaceName
        {
            get { return placeName; }
            set { placeName = value; }
        }
    }
}