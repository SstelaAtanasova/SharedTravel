﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data.SqlClient;
using System.IO;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace ShareYourTravels
{
    public partial class CarInfo : System.Web.UI.Page
    {
        string con = ConfigurationManager.ConnectionStrings["DefaultConnection"].ConnectionString;

        protected void Page_Load(object sender, EventArgs e)
        {

            if (!IsPostBack)
            {

                LoadCar();

              

            }
        }

        public void LoadCar()
        {
            using (SqlConnection connection = new SqlConnection(con))
            {

                connection.Open();
                SqlCommand command = new SqlCommand();
                command.CommandText = @"SELECT * FROM Car JOIN ModelCar ON Car.ModelID = ModelCar.ModelID 
                                                          JOIN BrandCar ON ModelCar.BrandID = BrandCar.BrandID                                                           
                                                 WHERE CarID= '" + Session["CarID"] + "'";
                command.Connection = connection;

                SqlDataReader reader = command.ExecuteReader();

                while (reader.Read())
                {
                    int carId = Convert.ToInt32(reader["CarID"]);
                    this.TextBoxBrand.Text = Convert.ToString(reader["Name"]);
                    this.TextBoxModel.Text = Convert.ToString(reader["ModelName"]);
                    this.TextBoxYear.Text = Convert.ToInt32(reader["Year"]).ToString();
                    this.TextBoxColor.Text = Convert.ToString(reader["Color"]);
                    this.ImageCar.ImageUrl = "~/Images/" + reader["Photo"];
                    

                }

                connection.Close();

            }
        }

        protected void ButtonSave_Click(object sender, EventArgs e)
        {
            using (SqlConnection connection = new SqlConnection(con))
            {
                if (FileUploadUpdatePhoto.HasFile)
                {
                    connection.Open();

                    string path = Path.GetFileName(FileUploadUpdatePhoto.FileName);
                    path = path.Replace(" ", "");
                    String Filename = path;
                    FileUploadUpdatePhoto.SaveAs(Server.MapPath("~/Images/") + path);


                    SqlCommand command = new SqlCommand();
                    command.CommandText = "UPDATE Car SET Year = @Year, Color = @Color, Photo = @Photo WHERE CarID= '" + Session["CarID"] + "'";
                    command.Connection = connection;

                    command.Parameters.AddWithValue("@Year", Convert.ToInt64(this.TextBoxYear.Text));
                    command.Parameters.AddWithValue("@Color", TextBoxColor.Text);
                    command.Parameters.AddWithValue("@Photo", path);

                    command.ExecuteNonQuery();

                    connection.Close();

                    this.Response.Redirect("AllCar.aspx");
                }
                else
                {
                    connection.Open();
                    SqlCommand command = new SqlCommand();
                    command.CommandText = "UPDATE Car SET Year = @Year, Color = @Color WHERE CarID= '" + Session["CarID"] + "'";
                    command.Connection = connection;

                    command.Parameters.AddWithValue("@Year", Convert.ToInt64(this.TextBoxYear.Text));
                    command.Parameters.AddWithValue("@Color", TextBoxColor.Text);
                    command.ExecuteNonQuery();

                    connection.Close();

                    this.Response.Redirect("AllCar.aspx");
                }
            }
        }

        protected void ButtonDelete_Click(object sender, EventArgs e)
        {
            using (SqlConnection connection = new SqlConnection(con))
            {

                connection.Open();
                SqlCommand command = new SqlCommand();
                command.CommandText = @"SELECT * FROM Car JOIN ModelCar ON Car.ModelID = ModelCar.ModelID 
                                                          JOIN BrandCar ON ModelCar.BrandID = BrandCar.BrandID   
                                                          JOIN Trip ON Car.CarID = Trip.CarID
                                                 WHERE Car.CarID= '" + Session["CarID"] + "'";

                command.Connection = connection;

                SqlDataReader reader = command.ExecuteReader();

                string carId = null;
                 if (reader.Read())
                 {
                    carId = Convert.ToString(reader["CarID"]);

                   
                 }
                reader.Close();

                if (carId == null)
                {
                    command.CommandText = "DELETE From Car Where CarID= '" + Session["CarID"] + "'";
                    command.Connection = connection;
                    command.ExecuteNonQuery();
                    connection.Close();
                    this.Response.Redirect("AllCar.aspx");
                }
                else
                {
                    LabelNotDelete.Visible = true;
                    LabelNotDelete.Text = "Не можете да изтриете този автомобил, защото вече участва в пътуване!";
                }


                
            }
        }



     


    }
}