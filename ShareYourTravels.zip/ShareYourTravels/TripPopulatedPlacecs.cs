﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.Linq;
using System.Web;

namespace ShareYourTravels
{
    public class TripPopulatedPlacecs
    {
        private int placeId;
        private int tripId;
        private string status;

        public int PlaceID
        {
            get { return placeId; }
            set { placeId = value; }
        }
        public int TripID
        {
            get { return tripId; }
            set { tripId = value; }
        }
        public string Status
        {
            get { return status; }
            set { status = value; }
        }
    }
}