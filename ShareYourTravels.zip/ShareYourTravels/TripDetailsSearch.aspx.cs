﻿using Microsoft.AspNet.Identity;
using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data.SqlClient;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace ShareYourTravels
{
    public partial class TripDetailsSearch : System.Web.UI.Page
    {
        string con = ConfigurationManager.ConnectionStrings["DefaultConnection"].ConnectionString;
        protected void Page_Load(object sender, EventArgs e)
        {
            if (User.Identity.IsAuthenticated)
            {
                ButtonJoin.Visible = true;
            }
                if (!IsPostBack)
            {

                using (SqlConnection connection = new SqlConnection(con))
                {
                    connection.Open();
                    SqlCommand command = new SqlCommand();
                    command.CommandText = @"SELECT   AspNetUsers.FirstName, AspNetUsers.LastName,	BrandCar.Name, ModelCar.ModelName, Car.Color, 
         Car.Year, Car.Photo, Trip.TripID, Trip.Date, Trip.FreeSeats, Trip.Price, Trip.MoreInformation, 
         Trip.Finished, Trip.PlaceBag, Trip.Smooking, Trip.FoodDrink, Trip.Pet, Trip.AirConditioning, 
		 (SELECT  PopulatedPlace.Name FROM PopulatedPlace JOIN TripPopulatedPlace ON TripPopulatedPlace.PlaceID = PopulatedPlace.PlaceID WHERE TripID = Trip.TripID AND Point like 'От') AS BeginCity,
  		 (SELECT  PopulatedPlace.Name FROM PopulatedPlace JOIN TripPopulatedPlace ON TripPopulatedPlace.PlaceID = PopulatedPlace.PlaceID WHERE TripID = Trip.TripID AND Point like 'До') As EndCity
						
FROM            AspNetUsers INNER JOIN UserTrip ON AspNetUsers.Id = UserTrip.UserID 
                            INNER JOIN Trip  ON Trip.TripID = UserTrip.TripID
							INNER JOIN Car  ON Car.CarID = Trip.CarID
							INNER JOIN ModelCar ON ModelCar.ModelID = Car.ModelID
							INNER JOIN BrandCar ON BrandCar.BrandID = ModelCar.BrandID
							INNER JOIN TripPopulatedPlace ON TripPopulatedPlace.TripID = Trip.TripID
							INNER JOIN PopulatedPlace ON PopulatedPlace.PlaceID = TripPopulatedPlace.PlaceID

WHERE  UserTrip.RoleID=1 AND Trip.TripID= '" + Session["TripID"] + "'";
                    command.Connection = connection;

                    SqlDataReader reader = command.ExecuteReader();
                    while (reader.Read())
                    {
                        LabelFirstName.Text = reader["FirstName"].ToString();
                        LabelLastName.Text = reader["LastName"].ToString();
                        LabelBrand.Text = reader["Name"].ToString();
                        LabelModel.Text = reader["ModelName"].ToString();
                        LabelYear.Text = reader["Year"].ToString();
                        LabelColor.Text = reader["Color"].ToString();
                        ImageCar.ImageUrl = "~/Images/" + reader["Photo"];
                        LabelFrom.Text = reader["BeginCity"].ToString();
                        LabelTo.Text = reader["EndCity"].ToString();
                        LabelDateTime.Text = reader["Date"].ToString();
                        LabelFreeSeats.Text = reader["FreeSeats"].ToString();
                        LabelPrice.Text = reader["Price"].ToString();

                        CheckBoxPlaceBag.Checked = Convert.ToBoolean(reader["PlaceBag"]);
                        CheckBoxSmooking.Checked = Convert.ToBoolean(reader["Smooking"]);
                        CheckBoxFood.Checked = Convert.ToBoolean(reader["FoodDrink"]);
                        CheckBoxPet.Checked = Convert.ToBoolean(reader["Pet"]);
                        CheckBoxAir.Checked = Convert.ToBoolean(reader["AirConditioning"]);
                        //che.Checked = Convert.ToBoolean(reader["Finished"]);

                        LabelMoreInfo.Text = reader["MoreInformation"].ToString();

                    }
                    connection.Close();
                }

            }
        }

        protected void ButtonJoin_Click(object sender, EventArgs e)
        {
            using (SqlConnection connection = new SqlConnection(con))
            {
                connection.Open();
                SqlCommand command = new SqlCommand();

                command.CommandText = "INSERT INTO UserTrip (TripID, UserID, RoleID) VALUES (@TripID, @UserID, @RoleID)";

                command.Parameters.AddWithValue("@UserID", HttpContext.Current.User.Identity.GetUserId());
                command.Parameters.AddWithValue("@TripID", Session["TripID"]);
                command.Parameters.AddWithValue("@RoleID", 2);
                command.Connection = connection;
                command.ExecuteNonQuery();

                connection.Close();

                this.Response.Redirect("UserTripRole.aspx");


            }
        }
    }
}